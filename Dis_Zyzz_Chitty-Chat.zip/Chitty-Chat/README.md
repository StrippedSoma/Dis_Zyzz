How to run Chitty-Chat
Open a terminal and go to the Chitty-Chat directory
Write "go run server/server.go" to create a server
Now open a new terminal and go to the Chitty-Chat directory
Write "go run client/client.go" to create a client
It will ask you to write your name/participant id
Now that client can send messages by writing in the terminal
Now you have created a server and a client
If you want to create another client then follow the steps from line 4-6
To leave the chat, type "/leave"